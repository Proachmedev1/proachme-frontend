
import React from 'react'

const dummyEvents = [
  {
    id: '1',
    title: 'ProachMe Launch Party',
    date: '2025-07-20',
    location: 'Barcelona, Spain',
    price: 0,
    status: 'published'
  },
  {
    id: '2',
    title: 'Mindful Leadership Retreat',
    date: '2025-08-10',
    location: 'Bali, Indonesia',
    price: 150,
    status: 'published'
  },
  {
    id: '3',
    title: 'Startup Networking Night',
    date: '2025-09-01',
    location: 'Remote (Zoom)',
    price: 10,
    status: 'published'
  }
]

export default function Events() {
  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-4">Available Events</h2>
      <ul className="space-y-4">
        {dummyEvents.map(event => (
          <li key={event.id} className="border rounded p-4 shadow">
            <h3 className="text-lg font-semibold">{event.title}</h3>
            <p>{event.date} • {event.location}</p>
            <p className="mt-1 text-sm text-gray-600">Price: {event.price === 0 ? 'Free' : `€${event.price}`}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}
